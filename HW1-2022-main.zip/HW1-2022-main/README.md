# hw1-2020
Starter code for HW1 along with screenshots of the final results.

Please clone this code rather thank forking.  Or better yet, feel free to download the code as a zip file.
